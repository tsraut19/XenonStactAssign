package com.SpringBootApp.service;

import org.springframework.stereotype.Service;

import com.SpringBootApp.model.ContactUs;

@Service
public interface ContactUsService {
	void add(ContactUs contact); 
}
