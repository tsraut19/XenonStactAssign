package com.SpringBootApp.service;

import org.springframework.stereotype.Service;

import com.SpringBootApp.model.User;

@Service
public interface UserService {
	
	void add(User user);   
	User login(User user); 
}
