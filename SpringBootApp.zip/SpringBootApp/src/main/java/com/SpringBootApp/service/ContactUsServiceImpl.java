package com.SpringBootApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootApp.dao.ContactUsDao;
import com.SpringBootApp.model.ContactUs;

@Service
public class ContactUsServiceImpl implements ContactUsService {

	@Autowired
	ContactUsDao contactUsDao;
	
	@Override
	public void add(ContactUs contact) {
		contactUsDao.save(contact);
		
	}

}
