package com.SpringBootApp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.SpringBootApp.model.Cars;

@Service
public interface CarsService {

	List<Cars> getCarList();
}
