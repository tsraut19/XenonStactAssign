package com.SpringBootApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootApp.dao.UserDao;
import com.SpringBootApp.model.User;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao; 
	
	@Override
	public void add(User user) {
		userDao.save(user);
	}

	@Override
	public User login(User user) {
		List<User> lst = new ArrayList<User>();
		lst = userDao.findAllActiveUsersNative(user.getEmail(),user.getPassword());
		User userq = userDao.findbyEmailId(user.getEmail());
		if(userq.getPassword().equals(user.getPassword()))
		{
			return userq;
		}
		if (lst.isEmpty() || lst==null) {
			return null;
		}
		else {
			return null;
		}
	}
	
}
