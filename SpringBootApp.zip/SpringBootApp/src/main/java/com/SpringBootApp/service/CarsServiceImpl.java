package com.SpringBootApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootApp.dao.CarsDao;
import com.SpringBootApp.model.Cars;

@Service
public class CarsServiceImpl implements CarsService {

	@Autowired
	CarsDao carsDao;
	

	@Override
	public List<Cars> getCarList() {
		Iterable<Cars> itr = carsDao.findAll();
		List<Cars> carlst = new ArrayList<Cars>();
		itr.forEach(ele->carlst.add(ele));
		return carlst;
	}

}
