package com.SpringBootApp.cntr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootApp.model.User;
import com.SpringBootApp.service.UserService;

@RestController
@CrossOrigin(origins ="*")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping(value = {"/user/add"}) 
	public String userAdd(@RequestBody User user) {
		userService.add(user);
		return "success";
	} 
	
	@PostMapping(value = {"/user/login"})
	public User userLogin(@RequestBody User user) {
		
		return userService.login(user);
	} 
	
}
