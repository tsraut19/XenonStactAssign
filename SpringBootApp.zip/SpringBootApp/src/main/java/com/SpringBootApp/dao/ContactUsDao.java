package com.SpringBootApp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBootApp.model.ContactUs;

public interface ContactUsDao extends JpaRepository<ContactUs, Integer> {

}
