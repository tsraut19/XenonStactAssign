package com.SpringBootApp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBootApp.model.Cars;

public interface CarsDao extends JpaRepository<Cars, Integer>{
	
}
