import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';


export function Footer (){

    return(
        <>
            <footer style={{ position: "absolute", bottom: 0, width: "100%" }}>
                <Navbar bg="dark" variant="dark">
                    <Container>
                        <Navbar.Brand className="ms-auto" href="./contact">Contact Us</Navbar.Brand>
                    </Container>
                </Navbar>
            </footer>
        </>
    );
}