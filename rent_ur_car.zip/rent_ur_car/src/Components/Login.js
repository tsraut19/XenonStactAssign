import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Row, Col } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { getLoginDetailsFromServer } from "../Services/ApiServices";

export function Login (){

    const [isLoggedIn, setLoggedIn] = useState(false);

    //---------- Managing session ----------
    useEffect(() => {
        if (
          sessionStorage.getItem("isActive") !== null &&
          sessionStorage.getItem("isActive") === "true"
        ) {
          setLoggedIn(true);
        }
      }, []);
    
      const initialData = {
        email: "",
        password: "",
      };

    const [formData, setFormData] = useState(initialData);
    
      const handleChange = (e) => {
        setFormData({
          ...formData,
          [e.target.name]: e.target.value,
        });
      };
    

      const navigate = useNavigate();

      const handleSubmit = async (event) => {
        event.preventDefault();
      
        const response = await getLoginDetailsFromServer(formData);
    
        console.log(response.data);
        console.log(response.data.email);
        console.log(formData.email);
    
        if (response.data.email == formData.email) {
          if (response.data.authenticate != 0) {
            sessionStorage.setItem("userEmail", response.data.email);
            sessionStorage.setItem("isActive", true);
            navigate("/");
          } else {
            alert("You are not authenticated!");
          }
        } else {
          alert("Incorrect email or password!");
        }
      };
    

    return(
        <>
            <h1>Login</h1>
            <Container style={{ width: '70rem', marginTop: '1rem', marginBottom: '1rem'}}>
            <Row>
            <Col md={6}>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" 
                        placeholder="Enter email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        />
                        <Form.Text className="text-muted">
                         We'll never share your email with anyone else.
                        </Form.Text>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password"
                        placeholder="Enter Password"
                        name="password"
                        onChange={handleChange}
                        required
                        />
                    </Form.Group>
            
                    <Button variant="primary" type="submit">
                        Submit
                    </Button>
                </Form>
                <Link to="/signup">New User? Sign up here</Link>
            </Col>
            </Row>
            </Container>
        </>
    );
}