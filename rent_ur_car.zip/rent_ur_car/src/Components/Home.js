import React, { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import Container from 'react-bootstrap/esm/Container';

export function Home (){
    const [loggedIn, setLoggedIn] = useState("false");
    const [data, setData] = useState([]);

    useEffect(() => {
        if (
          sessionStorage.getItem("isActive") != null &&
          sessionStorage.getItem("isActive") === "true"
        ) {
          setLoggedIn(true);
          fetch("http://localhost:8585/get-car-list")
            .then((response) => response.json())
            .then((data) => setData(data));
        } else {
          setLoggedIn(false);
        }
      }, []);

      console.log(data);

    return(
        <>
            <Container>
            {loggedIn ? (
            <div>
                <Table striped  sm bordered hover variant="dark">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Company Name</th>
                    <th>Modal</th>
                    <th>Type</th>
                    <th>Rent</th>
                  </tr>
                </thead>
                {data.map(item => (
                <tbody>
                  <tr>
                    <td>{item.cid}</td>
                    <td>{item.companyName}</td>
                    <td>{item.modalName}</td>
                    <td>{item.type}</td>
                    <td>{item.rent}</td>
                  </tr>
                </tbody>
                ))}
              </Table>
              
            </div>
            ) : (
            <div>
                {alert("You are not authenticated!")}
            </div>
            )}
            </Container>
        </>
    );
}