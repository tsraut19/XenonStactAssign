import React, {useState} from 'react';
import { Container, Form, Row, Col, Button }  from 'react-bootstrap';

export function ContactUs () {
    const [formData, setFormData] = useState({
        Name: '',
        mobNumber: '',
        email: '',
        textarea: '',
      });
    
    
      const handleChange = (e) => {
        setFormData({
          ...formData,
          [e.target.name]: e.target.value,
        });
      };
    
      const handleSubmit = (e) => {
        e.preventDefault();
        console.log(formData);
        fetch("http://localhost:8585/contact", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
          }).then(() => {
            console.log("New Contact added");
          });
        };
    

    return(
        <>
            <h1>Contact Us</h1>
            <Container style={{ width: '70rem', marginTop: '1rem', marginBottom: '1rem'}}>
            <Row>
            <Col md={6}>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Enter Name</Form.Label>
                        <Form.Control type="text" 
                        required
                        placeholder="Enter Full Name"
                        name="Name"
                        value={formData.Name}
                        onChange={handleChange}
                        />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control 
                        required
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        
                        placeholder="Email Address" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Enter Mobile Number</Form.Label>
                        <Form.Control placeholder="Enter Mobile Number"
                         required
                         type="text"
                         name="mobNumber"
                         value={formData.mobNumber}
                         onChange={handleChange}
                        />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                        <Form.Label>Message</Form.Label>
                        <Form.Control  
                        required
                        type="text"
                        name="textarea"
                        value={formData.textarea}
                        onChange={handleChange}
                        />
                    </Form.Group>

                    <Button variant="primary" type="submit">
                        Submit
                    </Button>
                </Form>
            </Col>
            </Row>
            </Container>
        </>
    );
}
