import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import {Home}  from './Components/Home';
import {Navigation} from './Components/Navigation';
import {Footer} from './Components/Footer';
import { Login } from './Components/Login';
import { ContactUs } from './Components/ContactUs';
import { Register } from './Components/Register';


function App() {
  return (
    <>
      <Navigation></Navigation>
      <div></div>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home></Home>}></Route>
        <Route path="/login" element={<Login></Login>}></Route>
        <Route path="/contact" element={<ContactUs></ContactUs>}></Route>
        <Route path="/signup" element={<Register></Register>}></Route>
      </Routes>

    </BrowserRouter>
    <div></div>
    <Footer></Footer>
    </>
  );
}

export default App;
