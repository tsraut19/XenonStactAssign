import axios from "axios";

const LOGIN_URL = "http://localhost:8585/user/login";



export async function getLoginDetailsFromServer(formData) {
    return axios.post(LOGIN_URL, formData);
  }